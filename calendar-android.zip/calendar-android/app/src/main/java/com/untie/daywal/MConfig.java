package com.untie.daywal;

/**
 * Default App Config
 * Created by brownsoo on 2014. 10. 4..
 */
public class MConfig {

    public static final String TAG = "proto";

}
